import os, sqlite3
from functools import wraps
from flask import Flask, g, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get('PUBAFRICA_SECRET', 'change-this-secret-in-production')
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
ALLOWED_EXTENSIONS = {'png','jpg','jpeg','webp'}
DB = os.path.join(os.path.dirname(__file__), 'pubafrica1.db')

def db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exception=None):
    conn = g.pop('db', None)
    if conn: conn.close()

def init_db():
    conn = db()
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'member', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS listings (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL, location TEXT NOT NULL, price TEXT, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS conversations (id INTEGER PRIMARY KEY, listing_id INTEGER NOT NULL, buyer_id INTEGER NOT NULL, seller_id INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(listing_id,buyer_id,seller_id));
    CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, conversation_id INTEGER NOT NULL, sender_id INTEGER NOT NULL, body TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY, listing_id INTEGER NOT NULL, reporter_id INTEGER NOT NULL, reason TEXT NOT NULL, description TEXT, status TEXT NOT NULL DEFAULT 'open', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS businesses (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, name TEXT NOT NULL, description TEXT, verification_status TEXT NOT NULL DEFAULT 'pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS listing_images (id INTEGER PRIMARY KEY, listing_id INTEGER NOT NULL, file_name TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    ''')
    conn.commit()

@app.before_request
def before_request(): init_db()

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get('role') not in ('admin','super_admin'):
            abort(403)
        return view(*args, **kwargs)
    return wrapped

def allowed_file(name):
    return '.' in name and name.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if 'user_id' not in session:
            flash('Connecte-toi pour continuer.', 'warning')
            return redirect(url_for('login'))
        return view(*args, **kwargs)
    return wrapped

@app.route('/')
def home():
    q = request.args.get('q','').strip()
    conn = db()
    if q:
        listings = conn.execute("SELECT l.*, u.name FROM listings l JOIN users u ON u.id=l.user_id WHERE l.status='published' AND (l.title LIKE ? OR l.description LIKE ? OR l.location LIKE ?) ORDER BY l.id DESC", (f'%{q}%',f'%{q}%',f'%{q}%')).fetchall()
    else:
        listings = conn.execute("SELECT l.*, u.name FROM listings l JOIN users u ON u.id=l.user_id WHERE l.status='published' ORDER BY l.id DESC").fetchall()
    return render_template('home.html', listings=listings, q=q)

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        name, email, password = request.form['name'].strip(), request.form['email'].strip().lower(), request.form['password']
        if not name or not email or len(password) < 6:
            flash('Renseigne tous les champs. Le mot de passe doit avoir 6 caractères minimum.', 'warning')
            return render_template('register.html')
        try:
            cur = db().execute('INSERT INTO users(name,email,password) VALUES(?,?,?)', (name,email,generate_password_hash(password)))
            db().commit(); session['user_id']=cur.lastrowid; session['user_name']=name; session['role']='member'
            flash('Compte créé. Bienvenue sur PubAfrica1 !','success'); return redirect(url_for('dashboard'))
        except sqlite3.IntegrityError:
            flash('Cette adresse e-mail est déjà utilisée.', 'warning')
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        user = db().execute('SELECT * FROM users WHERE email=?', (request.form['email'].strip().lower(),)).fetchone()
        if user and check_password_hash(user['password'], request.form['password']):
            session['user_id']=user['id']; session['user_name']=user['name']; session['role']=user['role']; return redirect(url_for('admin' if user['role'] in ('admin','super_admin') else 'dashboard'))
        flash('E-mail ou mot de passe incorrect.', 'warning')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear(); return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    listings = db().execute('SELECT * FROM listings WHERE user_id=? ORDER BY id DESC', (session['user_id'],)).fetchall()
    return render_template('dashboard.html', listings=listings)

@app.route('/publish', methods=['GET','POST'])
@login_required
def publish():
    if request.method == 'POST':
        data = [request.form.get(k,'').strip() for k in ('title','description','category','location','price')]
        if not all(data[:4]): flash('Complète les champs obligatoires.', 'warning')
        else:
            cur=db().execute('INSERT INTO listings(user_id,title,description,category,location,price,status) VALUES(?,?,?,?,?,?,?)', (*data, 'pending'))
            listing_id=cur.lastrowid
            for f in request.files.getlist('images'):
                if f and allowed_file(f.filename):
                    filename=f'{listing_id}_{session["user_id"]}_{secure_filename(f.filename)}'
                    f.save(os.path.join(UPLOAD_FOLDER, filename))
                    db().execute('INSERT INTO listing_images(listing_id,file_name) VALUES(?,?)',(listing_id,filename))
            db().commit()
            flash('Annonce envoyée. Elle sera visible après validation.', 'success'); return redirect(url_for('dashboard'))
    return render_template('publish.html')


@app.route('/admin')
@admin_required
def admin():
    conn = db()
    pending = conn.execute("SELECT l.*,u.name FROM listings l JOIN users u ON u.id=l.user_id WHERE l.status='pending' ORDER BY l.id DESC").fetchall()
    stats = {
        'users': conn.execute('SELECT COUNT(*) c FROM users').fetchone()['c'],
        'listings': conn.execute('SELECT COUNT(*) c FROM listings').fetchone()['c'],
        'pending': len(pending),
    }
    reports = conn.execute("SELECT r.*,l.title,u.name FROM reports r JOIN listings l ON l.id=r.listing_id JOIN users u ON u.id=r.reporter_id WHERE r.status='open' ORDER BY r.id DESC").fetchall()
    return render_template('admin.html', pending=pending, reports=reports, stats=stats)

@app.route('/admin/reports/<int:report_id>/resolve', methods=['POST'])
@admin_required
def resolve_report(report_id):
    db().execute("UPDATE reports SET status='resolved' WHERE id=?", (report_id,)); db().commit()
    flash('Signalement traité.', 'success'); return redirect(url_for('admin'))

@app.route('/admin/listings/<int:listing_id>/<decision>', methods=['POST'])
@admin_required
def moderate_listing(listing_id, decision):
    if decision not in ('published','rejected','hidden'):
        abort(400)
    db().execute('UPDATE listings SET status=? WHERE id=?', (decision, listing_id)); db().commit()
    flash('Décision enregistrée.', 'success')
    return redirect(url_for('admin'))

@app.route('/listing/<int:listing_id>/contact', methods=['POST'])
@login_required
def contact_seller(listing_id):
    item = db().execute("SELECT * FROM listings WHERE id=? AND status='published'", (listing_id,)).fetchone()
    if not item: abort(404)
    if item['user_id'] == session['user_id']:
        flash('Tu ne peux pas contacter ton propre compte.', 'warning'); return redirect(url_for('listing', listing_id=listing_id))
    conn=db()
    conn.execute('INSERT OR IGNORE INTO conversations(listing_id,buyer_id,seller_id) VALUES(?,?,?)',(listing_id,session['user_id'],item['user_id']))
    conv=conn.execute('SELECT id FROM conversations WHERE listing_id=? AND buyer_id=? AND seller_id=?',(listing_id,session['user_id'],item['user_id'])).fetchone()
    body=request.form.get('body','').strip() or 'Bonjour, votre annonce m’intéresse.'
    conn.execute('INSERT INTO messages(conversation_id,sender_id,body) VALUES(?,?,?)',(conv['id'],session['user_id'],body)); conn.commit()
    flash('Message envoyé.', 'success'); return redirect(url_for('messages'))

@app.route('/messages')
@login_required
def messages():
    rows=db().execute("SELECT c.id,c.listing_id,l.title, u.name as other_name, MAX(m.created_at) as last_message, (SELECT body FROM messages WHERE conversation_id=c.id ORDER BY id DESC LIMIT 1) as body FROM conversations c JOIN listings l ON l.id=c.listing_id JOIN users u ON u.id=CASE WHEN c.buyer_id=? THEN c.seller_id ELSE c.buyer_id END LEFT JOIN messages m ON m.conversation_id=c.id WHERE c.buyer_id=? OR c.seller_id=? GROUP BY c.id ORDER BY last_message DESC",(session['user_id'],session['user_id'],session['user_id'])).fetchall()
    return render_template('messages.html', conversations=rows)

@app.route('/report/<int:listing_id>', methods=['POST'])
@login_required
def report_listing(listing_id):
    reason=request.form.get('reason','').strip() or 'Contenu inapproprié'
    description=request.form.get('description','').strip()
    db().execute('INSERT INTO reports(listing_id,reporter_id,reason,description) VALUES(?,?,?,?)',(listing_id,session['user_id'],reason,description)); db().commit()
    flash('Merci. Ton signalement sera examiné.', 'success'); return redirect(url_for('listing',listing_id=listing_id))

@app.route('/listing/<int:listing_id>')
def listing(listing_id):
    item = db().execute("SELECT l.*,u.name FROM listings l JOIN users u ON u.id=l.user_id WHERE l.id=? AND l.status='published'", (listing_id,)).fetchone()
    if not item: return 'Annonce introuvable', 404
    images=db().execute('SELECT * FROM listing_images WHERE listing_id=? ORDER BY id',(listing_id,)).fetchall()
    return render_template('listing.html', item=item, images=images)

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)
