# Déploiement du MVP PubAfrica1

## Option serveur avec Docker

1. Installer Docker sur un serveur.
2. Copier le dossier `pubafrica1_mvp`.
3. Créer un fichier `.env` à partir de `.env.example`.
4. Remplacer `PUBAFRICA_SECRET` par une clé longue et secrète.
5. Construire et lancer :

```bash
docker build -t pubafrica1 .
docker run -d --name pubafrica1 -p 8000:8000 --env-file .env -v pubafrica1_data:/app/static/uploads pubafrica1
```

6. Relier un nom de domaine et activer HTTPS avec un proxy sécurisé.

## Avant ouverture au public

- utiliser PostgreSQL ou une base managée au lieu de SQLite ;
- utiliser un stockage objet pour les photos et justificatifs ;
- ajouter une sauvegarde automatique ;
- limiter taille et formats des fichiers ;
- activer une authentification administrateur renforcée ;
- configurer les e-mails et SMS de vérification ;
- tester les permissions, les uploads et les signalements ;
- ajouter les mentions légales, conditions d’utilisation et politique de confidentialité.

## Important

Le MVP fourni est un socle de développement. Le déploiement public doit être réalisé avec une configuration sécurisée et un domaine contrôlé par le propriétaire de PubAfrica1.
