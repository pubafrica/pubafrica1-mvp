# PubAfrica1 MVP — prototype fonctionnel local

## Lancer

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Ouvrir ensuite http://127.0.0.1:5000

## Fonctionnalités incluses
- inscription et connexion ;
- recherche d’annonces publiées ;
- espace membre ;
- création d’annonces ;
- statut de modération ;
- détail d’annonce.

Cette version est un socle de démonstration local. Avant production, ajouter stockage d’images, e-mail/SMS, modération admin, messagerie sécurisée, protection CSRF, migrations, tests, HTTPS et déploiement.

## Administration locale

Pour créer un administrateur de test, après avoir installé les dépendances, exécuter une commande Python ou modifier la base SQLite avec un compte dont le rôle est `admin`. En production, prévoir une création sécurisée et une authentification renforcée.

## Version 3

Ajouts : messagerie de contact, boîte de réception, signalements d’annonces et tables de vérification entreprise. Avant production, ajouter le traitement admin des signalements et la gestion complète des pièces justificatives.

## Version 3

Ajouts : messagerie de contact, boîte de réception, signalements d’annonces et tables de vérification entreprise.

## Version 4

Ajouts : envoi de plusieurs photos par annonce et file de traitement des signalements dans l’administration. En production, ajouter antivirus, limite de taille, stockage objet et redimensionnement d’images.

## Version 5

Ajouts : création d’une page entreprise, dépôt d’un justificatif et validation ou refus depuis l’administration. Pour la production, ajouter stockage sécurisé des documents, antivirus, contrôle des formats et règles de conservation.


## Déploiement

Voir `DEPLOIEMENT.md` et le `Dockerfile` inclus.
